import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ModuleHeader from '@/components/common/ModuleHeader';

/**
 * 🧪 YemekZen Core Components Unit Tests
 * 
 * Bu test suite temel component'lerin doğru çalıştığını kontrol eder
 */

describe('ModuleHeader Component', () => {
  const defaultProps = {
    title: 'Test Module',
    subtitle: 'Test module description',
    icon: '🍽️'
  };

  test('✅ ModuleHeader doğru render ediliyor', () => {
    render(<ModuleHeader {...defaultProps} />);
    
    expect(screen.getByText('Test Module')).toBeInTheDocument();
    expect(screen.getByText('Test module description')).toBeInTheDocument();
    expect(screen.getByText('🍽️')).toBeInTheDocument();
  });

  test('✅ ModuleHeader children ile çalışıyor', () => {
    render(
      <ModuleHeader {...defaultProps}>
        <button>Test Button</button>
      </ModuleHeader>
    );
    
    expect(screen.getByRole('button', { name: 'Test Button' })).toBeInTheDocument();
  });

  test('✅ ModuleHeader subtitle olmadan çalışıyor', () => {
    const { subtitle, ...propsWithoutSubtitle } = defaultProps;
    
    render(<ModuleHeader {...propsWithoutSubtitle} />);
    
    expect(screen.getByText('Test Module')).toBeInTheDocument();
    expect(screen.queryByText('Test module description')).not.toBeInTheDocument();
  });

  test('✅ ModuleHeader icon olmadan çalışıyor', () => {
    const { icon, ...propsWithoutIcon } = defaultProps;
    
    render(<ModuleHeader {...propsWithoutIcon} />);
    
    expect(screen.getByText('Test Module')).toBeInTheDocument();
    expect(screen.queryByText('🍽️')).not.toBeInTheDocument();
  });
});

describe('Health Check API', () => {
  test('✅ Health check response format doğru', async () => {
    const response = await fetch('http://localhost:3001/api/health');
    const data = await response.json();
    
    // Temel alanlar var mı?
    expect(data).toHaveProperty('status');
    expect(data).toHaveProperty('timestamp');
    expect(data).toHaveProperty('version');
    expect(data).toHaveProperty('environment');
    expect(data).toHaveProperty('database');
    expect(data).toHaveProperty('uptime');
    expect(data).toHaveProperty('memory');
    
    // Veri tipleri doğru mu?
    expect(typeof data.status).toBe('string');
    expect(typeof data.timestamp).toBe('string');
    expect(typeof data.version).toBe('string');
    expect(typeof data.environment).toBe('string');
    expect(typeof data.database).toBe('string');
    expect(typeof data.uptime).toBe('number');
    expect(typeof data.memory).toBe('object');
  });

  test('✅ Health check status healthy', async () => {
    const response = await fetch('http://localhost:3001/api/health');
    const data = await response.json();
    
    expect(data.status).toBe('healthy');
    expect(data.database).toBe('connected');
  });
});

describe('Environment Configuration', () => {
  test('✅ Environment değişkenleri doğru yükleniyor', () => {
    // Temel environment değişkenleri kontrol et
    expect(process.env.NODE_ENV).toBeDefined();
    expect(process.env.NEXT_PUBLIC_SUPABASE_URL).toBeDefined();
    expect(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY).toBeDefined();
  });

  test('✅ Supabase URL format doğru', () => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    
    expect(supabaseUrl).toMatch(/^https:\/\/.*\.supabase\.co$/);
  });

  test('✅ Supabase Anon Key format doğru', () => {
    const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    
    expect(anonKey).toMatch(/^eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/);
  });
});

describe('Database Schema Validation', () => {
  test('✅ Prisma schema geçerli', () => {
    // Prisma schema'nın geçerli olduğunu kontrol et
    // Bu test Prisma generate komutunun başarılı olmasıyla doğrulanır
    expect(true).toBe(true); // Placeholder - gerçek test Prisma generate ile
  });

  test('✅ Database bağlantısı aktif', async () => {
    const response = await fetch('http://localhost:3001/api/health');
    const data = await response.json();
    
    expect(data.database).toBe('connected');
  });
});

describe('Performance Benchmarks', () => {
  test('⚡ Health check API hızlı yanıt veriyor', async () => {
    const startTime = Date.now();
    
    const response = await fetch('http://localhost:3001/api/health');
    
    const responseTime = Date.now() - startTime;
    
    expect(responseTime).toBeLessThan(1000); // 1 saniyeden az
    expect(response.status).toBe(200);
  });

  test('⚡ Ana sayfa hızlı yükleniyor', async () => {
    const startTime = Date.now();
    
    const response = await fetch('http://localhost:3001');
    
    const responseTime = Date.now() - startTime;
    
    expect(responseTime).toBeLessThan(3000); // 3 saniyeden az
    expect(response.status).toBe(200);
  });
});

describe('Error Handling', () => {
  test('❌ Var olmayan endpoint 404 döndürüyor', async () => {
    const response = await fetch('http://localhost:3001/api/nonexistent');
    
    expect(response.status).toBe(404);
  });

  test('❌ Var olmayan sayfa 404 döndürüyor', async () => {
    const response = await fetch('http://localhost:3001/nonexistent-page');
    
    expect(response.status).toBe(404);
  });
});

describe('Security Tests', () => {
  test('🔐 Health check hassas bilgileri açığa çıkarmıyor', async () => {
    const response = await fetch('http://localhost:3001/api/health');
    const data = await response.json();
    
    // Hassas bilgiler response'da yok
    expect(data).not.toHaveProperty('password');
    expect(data).not.toHaveProperty('secret');
    expect(data).not.toHaveProperty('key');
    
    // Database URL maskeleme kontrolü
    if (data.database_url) {
      expect(data.database_url).not.toMatch(/\/\/.*@/); // Password görünmüyor
    }
  });

  test('🔐 Environment değişkenleri güvenli', () => {
    // Hassas environment değişkenleri client-side'da görünmüyor
    expect(process.env.DATABASE_URL).toBeUndefined(); // Client-side'da yok
    expect(process.env.DIRECT_URL).toBeUndefined(); // Client-side'da yok
    
    // Public environment değişkenleri var
    expect(process.env.NEXT_PUBLIC_SUPABASE_URL).toBeDefined();
    expect(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY).toBeDefined();
  });
}); 