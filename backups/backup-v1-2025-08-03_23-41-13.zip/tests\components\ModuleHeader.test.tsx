import { render, screen } from '@testing-library/react'
import ModuleHeader from '../../components/common/ModuleHeader'

describe('ModuleHeader', () => {
  const defaultProps = {
    title: 'Test Module',
    subtitle: 'Test module description',
    icon: '🍽️'
  }

  it('renders the title', () => {
    render(<ModuleHeader {...defaultProps} />)
    
    const title = screen.getByText('Test Module')
    expect(title).toBeInTheDocument()
  })

  it('renders the subtitle when provided', () => {
    render(<ModuleHeader {...defaultProps} />)
    
    const subtitle = screen.getByText('Test module description')
    expect(subtitle).toBeInTheDocument()
  })

  it('renders the icon when provided', () => {
    render(<ModuleHeader {...defaultProps} />)
    
    const icon = screen.getByText('🍽️')
    expect(icon).toBeInTheDocument()
  })

  it('does not render subtitle when not provided', () => {
    render(<ModuleHeader title="Test Module" icon="🍽️" />)
    
    const subtitle = screen.queryByText('Test module description')
    expect(subtitle).not.toBeInTheDocument()
  })

  it('renders children when provided', () => {
    render(
      <ModuleHeader {...defaultProps}>
        <button>Test Button</button>
      </ModuleHeader>
    )
    
    const button = screen.getByRole('button', { name: 'Test Button' })
    expect(button).toBeInTheDocument()
  })
}) 