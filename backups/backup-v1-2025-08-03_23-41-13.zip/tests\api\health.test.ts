import { NextRequest } from 'next/server'
import { GET } from '../../app/api/health/route'

describe('Health API', () => {
  it('returns 200 status with health information', async () => {
    const request = new NextRequest('http://localhost:3000/api/health')
    
    const response = await GET(request)
    
    expect(response.status).toBe(200)
    
    const data = await response.json()
    expect(data).toHaveProperty('status')
    expect(data).toHaveProperty('timestamp')
    expect(data).toHaveProperty('version')
    expect(data.status).toBe('healthy')
  })

  it('includes required health check fields', async () => {
    const request = new NextRequest('http://localhost:3000/api/health')
    
    const response = await GET(request)
    const data = await response.json()
    
    expect(data).toHaveProperty('database')
    expect(data).toHaveProperty('uptime')
    expect(data).toHaveProperty('environment')
  })
}) 